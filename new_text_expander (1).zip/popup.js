// chrome.storage.sync.get(['tag','content'], function(form){
//     $('#tag').text(form.tag);
//     $('#content').text(form.content);
//     console.log(form);
//     console.log(form.tag);
//     });